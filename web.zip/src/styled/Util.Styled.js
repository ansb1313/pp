
export const pxToRem = val => (`${val / 16}rem`);

