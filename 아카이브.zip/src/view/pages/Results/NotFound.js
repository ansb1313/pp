import React from 'react'
import styled from 'styled-components';

const NotFound = () => {
    
    return (
        <Container>
            NotFound
        </Container>
    )
}


const Container = styled.div`
    
`;

export default NotFound;