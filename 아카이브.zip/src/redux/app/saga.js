import {all} from "redux-saga/effects";

const saga = function* () {
    yield all([

    ])
}

export default saga;