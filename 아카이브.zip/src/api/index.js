import {FetchJson} from "../lib/Fetch";

const API = {
    // getData:(data) => FetchJson.get('/api', data),
}

export default API;